const Course = require("../models/Course");
const Category = require("../models/Category");
const mongoose = require("mongoose");

const isBlank = (value) => typeof value !== "string" || !value.trim();

const createCourse = async (req, res, next) => {
    try {
        const { title, description, instructor, category } = req.body || {};

        if (isBlank(title) || isBlank(description) || isBlank(instructor) || !category) {
            return res.status(400).json({
                success: false,
                message: "Title, description, instructor and category are required"
            });
        }

        if (!mongoose.isValidObjectId(category)) {
            return res.status(400).json({
                success: false,
                message: "Invalid category ID"
            });
        }

        const categoryExists = await Category.findById(category);

        if (!categoryExists) {
            return res.status(400).json({
                success: false,
                message: "Selected category does not exist"
            });
        }

        const course = await Course.create({
            title,
            description,
            instructor,
            category
        });

        res.status(201).json({
            success: true,
            message: "Course created successfully",
            course
        });
    } catch (error) {
        next(error);
    }
};

const getCourses = async (req, res, next) => {
    try {
        const courses = await Course.find()
            .populate("category", "name description")
            .sort({ createdAt: -1 });

        res.status(200).json({
            success: true,
            count: courses.length,
            courses
        });
    } catch (error) {
        next(error);
    }
};

const getCourseById = async (req, res, next) => {
    try {
        const { id } = req.params;

        if (!mongoose.isValidObjectId(id)) {
            return res.status(404).json({
                success: false,
                message: "Course not found"
            });
        }

        const course = await Course.findById(id)
            .populate("category", "name description");

        if (!course) {
            return res.status(404).json({
                success: false,
                message: "Course not found"
            });
        }

        res.status(200).json({
            success: true,
            course
        });
    } catch (error) {
        next(error);
    }
};

const updateCourse = async (req, res, next) => {
    try {
        const { id } = req.params;
        const { title, description, instructor, category } = req.body || {};

        if (!mongoose.isValidObjectId(id)) {
            return res.status(404).json({
                success: false,
                message: "Course not found"
            });
        }

        if (
            title === undefined &&
            description === undefined &&
            instructor === undefined &&
            category === undefined
        ) {
            return res.status(400).json({
                success: false,
                message: "Provide at least one field to update"
            });
        }

        if (
            (title !== undefined && isBlank(title)) ||
            (description !== undefined && isBlank(description)) ||
            (instructor !== undefined && isBlank(instructor))
        ) {
            return res.status(400).json({
                success: false,
                message: "Provided fields cannot be empty"
            });
        }

        if (category !== undefined) {
            if (!mongoose.isValidObjectId(category)) {
                return res.status(400).json({
                    success: false,
                    message: "Invalid category ID"
                });
            }

            const categoryExists = await Category.findById(category);

            if (!categoryExists) {
                return res.status(400).json({
                    success: false,
                    message: "Selected category does not exist"
                });
            }
        }

        const updates = {};
        if (title !== undefined) updates.title = title;
        if (description !== undefined) updates.description = description;
        if (instructor !== undefined) updates.instructor = instructor;
        if (category !== undefined) updates.category = category;

        const course = await Course.findByIdAndUpdate(
            id,
            updates,
            {
                new: true,
                runValidators: true
            }
        ).populate("category", "name description");

        if (!course) {
            return res.status(404).json({
                success: false,
                message: "Course not found"
            });
        }

        res.status(200).json({
            success: true,
            message: "Course updated successfully",
            course
        });
    } catch (error) {
        next(error);
    }
};

const deleteCourse = async (req, res, next) => {
    try {
        const { id } = req.params;

        if (!mongoose.isValidObjectId(id)) {
            return res.status(404).json({
                success: false,
                message: "Course not found"
            });
        }

        const course = await Course.findByIdAndDelete(id);

        if (!course) {
            return res.status(404).json({
                success: false,
                message: "Course not found"
            });
        }

        res.status(200).json({
            success: true,
            message: "Course deleted successfully"
        });
    } catch (error) {
        next(error);
    }
};

module.exports = {
    createCourse,
    getCourses,
    getCourseById,
    updateCourse,
    deleteCourse
};
